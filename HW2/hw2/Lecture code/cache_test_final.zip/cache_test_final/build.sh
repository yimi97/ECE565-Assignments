#! /bin/bash

gcc -O2 -o cache_test cache_test.c -lrt
